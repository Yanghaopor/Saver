var a=Number(0),b=Number(0);
a = prompt("请输入一个数字");
b = prompt("请输入一个数字")
document.write("<h1>"+(Number(a)+Number(b))+"</h1>");